 <html lang = 'en'>
	<head>
		<title>
			Project
		</title>
        <link rel="stylesheet" href="project_styling.css">
	</head>
	<body>
		<ul class="navbar">
			<li><a id= "home" href="/index.php"> Home </a></li>
			<li><a id= "tetris" href="/tetris.php"> Play Tetris </a></li>
			<li><a id="leaderboard" href="/leaderboard.php">Leaderboard</a></li>
		</ul>
        <div class = "main">
<!-- NOTE: no closing tags should be used, because this code is simply run in
the start of every page using the include_once.php Any closing is done in the
file that calls this or via a call to footer.-->
