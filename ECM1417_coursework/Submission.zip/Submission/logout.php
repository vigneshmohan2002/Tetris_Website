<?php
header("location: /index.php?session=destroy");
exit;
?>