<?php
    include_once 'header.php';
?>
<div class = lander>
<button id="start-button">Start the game</button>
<div id = tetris-game class = tetris-bg> </div>
<div id="ScoreBox" style="visibility: hidden"></div>
<script src="new_tetris.js"></script>
</div>
